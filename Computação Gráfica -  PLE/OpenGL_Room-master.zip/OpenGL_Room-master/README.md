# opengl_room
The code contains a 3D scene created using OpenGL. The scene includes a 3D room with a glass cube & a stack of books on a table, multiple reflections and shadows caused by a moving light source.
Collaborators : G.S.N. Weragoda, H.M.J.D.Herath, W.D.C.J.Tennakoon
