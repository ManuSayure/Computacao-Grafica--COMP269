	3D-HOME-OpenGL-14.8
	====================
	
	Go to Folder 'ProgramOutPut' and click '3D_Home_OpenGL.exe'
	===========================================================
	
	Tools:
	======
		1. CodeBlocks
		2. GLUT
		3. C++
		
	Installation: 32 bit computer.
	==============================
		1. copy glut32.dll file in C:\Windows\System32 folder
		
	Installation: 64 bit computer.
	==============================
		1. copy 'glut32.dll' file in 'C:\Windows\System32' folder
			& also in 'C:\Windows\SysWOW64' folder.
		
	Run Program:
	============
		1. Install CodeBlocks
		2. Click Home.cbp
		3. copy all images to 'C:\Program Files\CodeBlocks\bin' folder
		4. F9 to run program.
	
	Keyboard event:
	===============
		1. Exit Esc button.
		2. Rotate: 8 - 6 - 2 - 4
		3. F1 to exit full screen.