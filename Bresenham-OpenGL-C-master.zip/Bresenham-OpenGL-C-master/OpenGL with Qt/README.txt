Comandos para build

qmake
make
