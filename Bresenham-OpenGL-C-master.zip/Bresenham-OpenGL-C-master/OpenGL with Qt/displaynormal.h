#ifndef DISPLAYNORMAL_H
#define DISPLAYNORMAL_H

class DisplayNormal {

public:
    void setLine(int x1,int x2,int y1,int y2,int line, float r, float g, float b);

    void displayNormal(float r, float g, float b, int line);
};

#endif // DISPLAYNORMAL_H
